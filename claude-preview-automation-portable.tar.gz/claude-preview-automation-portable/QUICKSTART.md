# ⚡ Quick Start Guide

## For Users (Human)

### 1. Extract the Package
```bash
tar -xzf claude-preview-automation-portable.tar.gz -C /path/to/your/project
cd /path/to/your/project
```

### 2. Install (Interactive)
```bash
bash claude-preview-automation/install.sh
```

### 3. Start Services
```bash
bash .codespace-automation/scripts/claude-preview start
```

### 4. Access Dashboard
Open in browser: `https://${CODESPACE_NAME}-8080.app.github.dev`

---

## For AI Assistants

### Step-by-Step Installation

```bash
# 1. Extract (already done if you're reading this)
cd /path/to/project

# 2. Check for conflicts
bash claude-preview-automation/scripts/check-conflicts.sh

# 3. If conflicts found, disable them
bash claude-preview-automation/scripts/disable-existing.sh

# 4. Run installation (non-interactive for AI)
bash claude-preview-automation/install.sh --yes

# 5. Verify installation
bash claude-preview-automation/scripts/verify-install.sh

# 6. Start services
bash .codespace-automation/scripts/claude-preview start

# 7. Check status
bash .codespace-automation/scripts/claude-preview status
```

### Expected Output
```
✅ Installation complete!
✅ All services started!
📊 Dashboard: https://${CODESPACE_NAME}-8080.app.github.dev
🎯 Preview: https://${CODESPACE_NAME}-5173.app.github.dev
```

### Common Issues

**PM2 not found:**
```bash
npm install -g pm2
```

**Port already in use:**
```bash
bash claude-preview-automation/scripts/disable-existing.sh
```

**Services won't start:**
```bash
pm2 logs
# Check error messages and install missing dependencies
```

---

## What This Package Contains

- **Automated Git Watcher**: Detects Claude.ai branch commits
- **Auto-Start Dev Server**: Supports Next.js, Vite, React, Vue
- **Preview Dashboard**: bolt.diy-style interface at port 8080
- **Health Monitoring**: Auto-recovery every 30 seconds
- **Performance Optimizations**: 80% faster startup (<30s vs 2-3min)

## Documentation

- Full instructions: `AI-INSTRUCTIONS.md`
- Usage guide: `claude-preview-automation/README.md`
- Setup details: `claude-preview-automation/docs/SETUP.md`

---

**Package Version**: 1.0.0
**Compatibility**: GitHub Codespaces, Node 18+, pnpm/npm/yarn
**License**: MIT
