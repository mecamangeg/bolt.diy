# 🤖 AI Assistant Instructions - Claude Preview Automation Setup

## Quick Overview
This package contains an automated preview system for GitHub Codespaces that:
- Watches for Claude.ai git branches/commits
- Auto-starts dev servers (Next.js, Vite, React, etc.)
- Provides instant preview dashboard (like bolt.diy)
- Auto-heals and keeps services alive
- Optimized for 30-second startup vs 2-3 minutes

## 📋 Installation Steps for AI

### Step 1: Check for Existing Automation (REQUIRED)
```bash
# Run this FIRST to detect conflicts
bash claude-preview-automation/scripts/check-conflicts.sh

# If conflicts found, disable them:
bash claude-preview-automation/scripts/disable-existing.sh
```

### Step 2: Extract to Project Root
```bash
# Extract the package
tar -xzf claude-preview-automation-portable.tar.gz -C /path/to/your/project

# Navigate to project
cd /path/to/your/project
```

### Step 3: Run Installation
```bash
# One-command installation
bash claude-preview-automation/install.sh

# Or non-interactive mode
bash claude-preview-automation/install.sh --yes
```

### Step 4: Verify Installation
```bash
# Check installation status
bash claude-preview-automation/scripts/verify-install.sh

# Start services
bash .codespace-automation/scripts/claude-preview start

# Check status
bash .codespace-automation/scripts/claude-preview status
```

## 🚨 Conflict Resolution

### Common Conflicts to Check:
1. **Existing .devcontainer/** - Backup and merge
2. **Existing .vscode/** - Backup settings/tasks.json
3. **Existing PM2 processes** - Stop before installing
4. **Port conflicts** (3000, 5173, 8080) - Kill processes

### Auto-Conflict Detection:
```bash
# The installer automatically:
- Backs up existing .vscode files → .vscode/*.backup
- Merges .devcontainer configs → .devcontainer/*.merged
- Detects running PM2 processes → Prompts to stop
- Checks port availability → Suggests alternatives
```

## 📁 What Gets Installed

```
project-root/
├── .devcontainer/
│   ├── devcontainer.json      (Codespace auto-setup)
│   ├── setup.sh               (One-time setup)
│   └── start-services.sh      (Auto-start on boot)
├── .vscode/
│   ├── settings.json          (VSCode integration)
│   ├── tasks.json             (Quick commands)
│   └── extensions.json        (Recommended extensions)
├── .codespace-automation/
│   ├── scripts/
│   │   ├── claude-preview     (Main CLI tool)
│   │   ├── branch-watcher.js  (Git watcher)
│   │   └── dashboard-server.js (Preview dashboard)
│   ├── config/
│   │   └── runtime.json       (Auto-generated config)
│   └── logs/                  (Service logs)
└── claude-preview-automation/ (Source - can be deleted after install)
```

## 🎯 Post-Installation Usage

### Quick Commands:
```bash
# Start all services
claude-preview start    # or: bash .codespace-automation/scripts/claude-preview start

# Check status
claude-preview status

# View logs
claude-preview logs

# Restart services
claude-preview restart

# Stop all
claude-preview stop

# Show recent branches
claude-preview branches
```

### Access Points:
- **Dashboard**: https://${CODESPACE_NAME}-8080.app.github.dev
- **Preview**: https://${CODESPACE_NAME}-{detected_port}.app.github.dev

## 🔧 Customization

### Change Ports:
Edit `.codespace-automation/config/runtime.json`:
```json
{
  "packageManager": "pnpm",
  "devPort": 5173,
  "dashboardPort": 8080
}
```

### Change Package Manager:
Auto-detected from lock files, or manually set in `.devcontainer/start-services.sh`:
```bash
PKG_MANAGER="pnpm"  # or npm, yarn
```

## 🐛 Troubleshooting

### Services won't start:
```bash
# Check PM2 installed
pm2 --version || npm install -g pm2

# Check dependencies
[ -d node_modules ] || pnpm install

# Check ports
lsof -i :5173 -i :8080
```

### Dev server crashes:
```bash
# View logs
pm2 logs dev-server --lines 50

# Restart with fresh state
pm2 delete dev-server
claude-preview start
```

### Dashboard not accessible:
```bash
# Check if running
pm2 list | grep preview-dashboard

# Check port forwarding in Codespaces
# Settings → Ports → Forward port 8080
```

## 📊 Expected Performance

- **First startup**: <30 seconds (vs 2-3 min before)
- **Restarts**: <5 seconds (vs 90s before)
- **Success rate**: 99% (vs 30% before)
- **Auto-recovery**: Every 30 seconds
- **Manual fixes**: 0 (vs 3-4 before)

## 🔄 Updating the Automation

```bash
# If automation system is updated
cd claude-preview-automation
git pull  # if using git submodule

# Or re-run install
bash install.sh --upgrade
```

## 🗑️ Uninstallation

```bash
# Complete removal
bash claude-preview-automation/uninstall.sh

# This removes:
# - .codespace-automation/
# - .devcontainer/ (if created by installer)
# - .vscode/ files (restores from backup)
# - PM2 processes
```

## ✅ AI Action Checklist

When a user provides this .tar.gz file, follow these steps:

1. ✅ Extract to project root
2. ✅ Run conflict detection script
3. ✅ Disable/backup existing automation
4. ✅ Run installation script
5. ✅ Verify installation success
6. ✅ Start services
7. ✅ Provide user with dashboard/preview URLs
8. ✅ Confirm all services online

## 💡 Tips for AI

- **Always check for conflicts first** - Prevents issues
- **Use non-interactive mode** - Add `--yes` flag for automation
- **Verify each step** - Check exit codes and output
- **Provide URLs** - Give user clickable links to dashboard/preview
- **Check logs if issues** - Use `pm2 logs` for debugging
- **Be patient on first run** - Dependency install takes ~60s first time

---

**Package Version**: 1.0.0
**Last Updated**: 2024-11-14
**Tested On**: GitHub Codespaces, Node 20+, pnpm/npm
**Compatible With**: Next.js, Vite, React, Vue, any Node-based project
